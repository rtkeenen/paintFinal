package States

abstract class State(brush: Brush) {

  def brushSize1(): Unit

  def brushSize2(): Unit

  def brushSize3(): Unit

  def brushSize4(): Unit

  def brushSize5(): Unit

}
